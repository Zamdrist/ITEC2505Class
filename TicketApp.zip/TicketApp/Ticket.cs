﻿using System;

namespace TicketApp
{
    class Ticket
    {
	    public decimal TicketNumber { get; set; }
	    public DateTime TimeScheduled { get; set; }

    }
}
